import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas unitarias del ciclo 4 de SlotMachine.
 */
public class SlotMachineC4Test
{
    /**
     * Prueba que se pueden crear los nuevos tipos de ruedas.
     */
    @Test
    public void shouldCreateDifferentWheelTypes()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1, "lefty");
        machine.addWheel(2, "rebel");
        machine.addWheel(3, "righty");

        assertTrue(machine.ok());
    }

    /**
     * Prueba que una rueda rebel no puede fijarse.
     */
    @Test
    public void rebelWheelShouldNotBeFixed()
    {
        RebelWheel wheel = new RebelWheel();

        assertFalse(wheel.canFix());
    }

    /**
     * Prueba que una rebel no puede intercambiarse.
     */
    @Test
    public void rebelWheelShouldNotBeExchanged()
    {
        RebelWheel wheel = new RebelWheel();

        assertFalse(wheel.canExchange());
    }

    /**
     * Prueba que una rebel no puede eliminarse.
     */
    @Test
    public void rebelWheelShouldNotBeDeleted()
    {
        RebelWheel wheel = new RebelWheel();

        assertFalse(wheel.canDelete());
    }

    /**
     * Prueba que un simbolo ephemeral disminuye su tamaño.
     */
    @Test
    public void ephemeralSymbolShouldDecreaseItsSize()
    {
        EphemeralSymbol symbol =
            new EphemeralSymbol("red", "red");

        int originalSize = symbol.getSize();

        symbol.onWheelSpin();

        assertTrue(symbol.getSize() < originalSize);
    }

    /**
     * Prueba que el tamaño del ephemeral
     * nunca llega a cero.
     */
    @Test
    public void ephemeralSymbolShouldNotBecomeZero()
    {
        EphemeralSymbol symbol =
            new EphemeralSymbol("red", "red");

        for (int i = 0; i < 30; i++)
        {
            symbol.onWheelSpin();
        }

        assertTrue(symbol.getSize() >= 1);
    }

    /**
     * Prueba que un simbolo shy cambia su visibilidad.
     */
    @Test
    public void shySymbolShouldAlternateVisibility()
    {
        ShySymbol symbol =
            new ShySymbol("blue", "blue");

        boolean initial = symbol.isShyVisible();

        symbol.onSelected();

        assertNotEquals(initial, symbol.isShyVisible());

        symbol.onSelected();

        assertEquals(initial, symbol.isShyVisible());
    }

    /**
     * Prueba el nuevo simbolo ColorShift.
     */
    @Test
    public void colorShiftSymbolShouldChangeColor()
    {
        ColorShiftSymbol symbol =
            new ColorShiftSymbol("red", "red");

        String initial = symbol.getColor();

        symbol.onSelected();

        assertNotEquals(initial, symbol.getColor());
    }

    /**
     * Prueba que la lefty copia la posicion
     * de la rueda izquierda.
     */
    @Test
    public void leftyWheelShouldCopyLeftPosition()
    {
        Wheel left = new Wheel();
        LeftyWheel lefty = new LeftyWheel();

        left.addSymbol(new Symbol("red", "red"));
        left.addSymbol(new Symbol("blue", "blue"));
        left.addSymbol(new Symbol("green", "green"));

        lefty.addSymbol(new Symbol("red", "red"));
        lefty.addSymbol(new Symbol("blue", "blue"));
        lefty.addSymbol(new Symbol("green", "green"));

        lefty.setLeftWheel(left);

        left.spin(1);
        lefty.spin(1);

        assertEquals(
            left.getPosition(),
            lefty.getPosition()
        );
    }

    /**
     * Prueba que la righty copia la posicion
     * de la rueda derecha.
     */
    @Test
    public void rightyWheelShouldCopyRightPosition()
    {
        RightyWheel righty = new RightyWheel();
        Wheel right = new Wheel();

        right.addSymbol(new Symbol("red", "red"));
        right.addSymbol(new Symbol("blue", "blue"));
        right.addSymbol(new Symbol("green", "green"));

        righty.addSymbol(new Symbol("red", "red"));
        righty.addSymbol(new Symbol("blue", "blue"));
        righty.addSymbol(new Symbol("green", "green"));

        righty.setRightWheel(right);

        right.spin(2);
        righty.spin(1);

        assertEquals(
            right.getPosition(),
            righty.getPosition()
        );
    }
}