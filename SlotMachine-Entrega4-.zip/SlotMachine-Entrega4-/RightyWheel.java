/**
 * Rueda que copia el estado de la rueda que tiene a su derecha.
 */
public class RightyWheel extends Wheel
{
    private Wheel rightWheel;

    /**
     * Crea una rueda Righty.
     */
    public RightyWheel()
    {
        super();
        rightWheel = null;
    }

    /**
     * Define la rueda de la derecha.
     *
     * @param rightWheel rueda derecha.
     */
    public void setRightWheel(Wheel rightWheel)
    {
        this.rightWheel = rightWheel;
    }

    /**
     * Gira copiando el estado de la rueda derecha.
     *
     * @param steps numero de pasos.
     */
    @Override
    public void spin(int steps)
    {
        if (rightWheel == null)
        {
            super.spin(steps);
            return;
        }

        copyPosition(rightWheel.getPosition());

        Symbol selected = getVisibleSymbol();

        if (selected != null)
        {
            selected.onWheelSpin();
            selected.onSelected();
        }
    }

    /**
     * Retorna el tipo.
     *
     * @return righty.
     */
    @Override
    public String getType()
    {
        return "righty";
    }

    /**
     * Color visual.
     *
     * @return magenta.
     */
    @Override
    public String getWindowColor()
    {
        return "magenta";
    }
}