/**
 * Simbolo que alterna entre visible e invisible
 * cada vez que es seleccionado.
 */
public class ShySymbol extends Symbol
{
    private boolean shyVisible;

    /**
     * Crea un simbolo shy.
     *
     * @param name nombre.
     * @param color color.
     */
    public ShySymbol(String name, String color)
    {
        super(name, color);
        shyVisible = true;
    }

    /**
     * Alterna la visibilidad del simbolo.
     */
    @Override
    public void onSelected()
    {
        shyVisible = !shyVisible;

        if (shyVisible)
        {
            makeVisible();
        }
        else
        {
            makeInvisible();
        }
    }

    /**
     * Indica si el simbolo debe mostrarse.
     *
     * @return true si es visible.
     */
    public boolean isShyVisible()
    {
        return shyVisible;
    }

    /**
     * Retorna el tipo del simbolo.
     *
     * @return tipo.
     */
    public String getType()
    {
        return "shy";
    }
}