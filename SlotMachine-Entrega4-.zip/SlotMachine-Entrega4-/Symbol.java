/**
 * Representa un simbolo de la maquina tragamonedas.
 */
public class Symbol
{
    private String name;
    private String color;
    private Circle figure;
    private int size;

    private static final int INITIAL_SIZE = 60;

    /**
     * Crea un simbolo.
     *
     * @param name nombre del simbolo.
     * @param color color del simbolo.
     */
    public Symbol(String name, String color)
    {
        this.name = name;
        this.color = color;
        this.size = INITIAL_SIZE;

        figure = new Circle();
        figure.changeSize(size);
        figure.changeColor(color);
        figure.makeInvisible();
    }

    /**
     * Retorna el nombre del simbolo.
     *
     * @return nombre.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Retorna el color del simbolo.
     *
     * @return color.
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Retorna el tamaño actual del simbolo.
     *
     * @return tamaño.
     */
    public int getSize()
    {
        return size;
    }

    /**
     * Cambia el tamaño del simbolo.
     *
     * @param newSize nuevo tamaño.
     */
    protected void changeSize(int newSize)
    {
        if (newSize < 1)
        {
            newSize = 1;
        }

        size = newSize;
        figure.changeSize(size);
    }

    /**
     * Cambia el color del simbolo.
     *
     * @param newColor nuevo color.
     */
    protected void changeSymbolColor(String newColor)
    {
        if (newColor == null || newColor.length() == 0)
        {
            return;
        }

        color = newColor;
        figure.changeColor(newColor);
    }

    /**
     * Metodo ejecutado cada vez que la rueda gira.
     *
     * La implementacion normal no necesita hacer nada.
     */
    public void onWheelSpin()
    {
        // El simbolo normal no cambia al girar.
    }

    /**
     * Metodo ejecutado cuando el simbolo es seleccionado.
     *
     * La implementacion normal no necesita hacer nada.
     */
    public void onSelected()
    {
        // El simbolo normal no cambia al ser seleccionado.
    }

    /**
     * Hace visible el simbolo.
     */
    public void makeVisible()
    {
        figure.makeVisible();
    }

    /**
     * Hace invisible el simbolo.
     */
    public void makeInvisible()
    {
        figure.makeInvisible();
    }

    /**
     * Oculta solamente la figura.
     *
     * Este metodo se utiliza para redibujar sin cambiar
     * el estado especial del simbolo.
     */
    void hideFigure()
    {
        figure.makeInvisible();
    }

    /**
     * Mueve el simbolo a una posicion absoluta.
     *
     * @param x coordenada horizontal.
     * @param y coordenada vertical.
     */
    public void moveTo(int x, int y)
    {
        figure.moveHorizontal(x - figure.getX());
        figure.moveVertical(y - figure.getY());
    }
}