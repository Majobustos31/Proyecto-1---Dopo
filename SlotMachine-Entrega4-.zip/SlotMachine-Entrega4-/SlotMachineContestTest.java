import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas para la clase SlotMachineContest.
 */
public class SlotMachineContestTest
{
    /**
     * Prueba que solve encuentre correctamente
     * los pasos para cada rueda.
     */
    @Test
    public void shouldSolveMachine()
    {
        String[][] machine = {
            {"A", "B", "C", "D"},
            {"B", "C", "D", "A"},
            {"C", "D", "A", "B"},
            {"D", "A", "B", "C"}
        };

        int[] expected = {0, 3, 2, 1};

        int[] result = SlotMachineContest.solve(machine);

        assertArrayEquals(expected, result);
    }

    /**
     * Prueba que la solucion encontrada por solve
     * realmente funcione.
     */
    @Test
    public void shouldSimulateCorrectSolution()
    {
        String[][] machine = {
            {"A", "B", "C", "D"},
            {"B", "C", "D", "A"},
            {"C", "D", "A", "B"},
            {"D", "A", "B", "C"}
        };

        int[] solution = SlotMachineContest.solve(machine);

        assertTrue(
            SlotMachineContest.simulate(machine, solution)
        );
    }

    /**
     * Prueba una solucion incorrecta.
     */
    @Test
    public void shouldRejectWrongSolution()
    {
        String[][] machine = {
            {"A", "B", "C", "D"},
            {"B", "C", "D", "A"},
            {"C", "D", "A", "B"}
        };

        int[] wrongSolution = {0, 0, 0};

        assertFalse(
            SlotMachineContest.simulate(machine, wrongSolution)
        );
    }

    /**
     * Prueba una maquina vacia.
     */
    @Test
    public void shouldSolveEmptyMachine()
    {
        String[][] machine = {};

        int[] result = SlotMachineContest.solve(machine);

        assertEquals(0, result.length);
    }

    /**
     * Prueba una maquina con una sola rueda.
     */
    @Test
    public void shouldSolveOneWheel()
    {
        String[][] machine = {
            {"A", "B", "C", "D"}
        };

        int[] expected = {0};

        int[] result = SlotMachineContest.solve(machine);

        assertArrayEquals(expected, result);

        assertTrue(
            SlotMachineContest.simulate(machine, result)
        );
    }

    /**
     * Prueba que simulate rechace una solucion
     * con una cantidad incorrecta de ruedas.
     */
    @Test
    public void shouldRejectWrongSolutionSize()
    {
        String[][] machine = {
            {"A", "B", "C"},
            {"B", "C", "A"}
        };

        int[] solution = {0};

        assertFalse(
            SlotMachineContest.simulate(machine, solution)
        );
    }
}