import java.util.ArrayList;

/**
 * Representa una rueda de la maquina tragamonedas.
 */
public class Wheel
{
    private ArrayList<Symbol> symbols;
    private int position;
    private boolean fixed;

    /**
     * Crea una rueda vacia.
     */
    public Wheel()
    {
        symbols = new ArrayList<Symbol>();
        position = 0;
        fixed = false;
    }

    /**
     * Agrega un simbolo a la rueda.
     *
     * @param symbol simbolo que se desea agregar.
     */
    public void addSymbol(Symbol symbol)
    {
        if (symbol == null) return;

        symbols.add(symbol);
        position = symbols.size() - 1;
    }

    /**
     * Elimina un simbolo de la rueda.
     *
     * @param name nombre del simbolo.
     * @return true si se elimino.
     */
    public boolean removeSymbol(String name)
    {
        int index = findSymbol(name);

        if (index == -1)
        {
            return false;
        }

        symbols.get(index).makeInvisible();
        symbols.remove(index);

        if (symbols.size() == 0)
        {
            position = 0;
        }
        else if (position >= symbols.size())
        {
            position = 0;
        }

        if (symbols.size() > 0)
        {
            symbols.get(position).makeVisible();
        }

        return true;
    }

    /**
     * Gira la rueda el numero de pasos indicado.
     *
     * @param steps numero de pasos.
     */
    public void spin(int steps)
    {
        if (symbols.size() == 0 || fixed) return;

        for (int i = 0; i < steps; i++)
        {
            position = (position + 1) % symbols.size();

            Symbol selected = getVisibleSymbol();

            if (selected != null)
            {
                selected.onWheelSpin();
                selected.onSelected();
            }
        }
    }

    /**
     * Retorna el simbolo actualmente visible.
     *
     * @return simbolo visible.
     */
    public Symbol getVisibleSymbol()
    {
        if (symbols.size() == 0)
        {
            return null;
        }

        return symbols.get(position);
    }

    /**
     * Busca un simbolo por nombre.
     *
     * @param name nombre.
     * @return posicion del simbolo o -1.
     */
    private int findSymbol(String name)
    {
        for (int i = 0; i < symbols.size(); i++)
        {
            if (symbols.get(i).getName().equals(name))
            {
                return i;
            }
        }

        return -1;
    }

    /**
     * Retorna la cantidad de simbolos.
     *
     * @return cantidad.
     */
    public int getNumberSymbols()
    {
        return symbols.size();
    }

    /**
     * Fija la rueda.
     */
    public void fix()
    {
        fixed = true;
    }

    /**
     * Suelta la rueda.
     */
    public void release()
    {
        fixed = false;
    }

    /**
     * Indica si esta fijada.
     *
     * @return true si esta fijada.
     */
    public boolean isFixed()
    {
        return fixed;
    }

    /**
     * Retorna el simbolo anterior.
     *
     * @return simbolo anterior.
     */
    public Symbol getPreviousSymbol()
    {
        if (symbols.size() <= 1) return null;

        int prev = (position - 1 + symbols.size()) % symbols.size();

        return symbols.get(prev);
    }

    /**
     * Retorna el siguiente simbolo.
     *
     * @return simbolo siguiente.
     */
    public Symbol getNextSymbol()
    {
        if (symbols.size() <= 1) return null;

        int next = (position + 1) % symbols.size();

        return symbols.get(next);
    }

    /**
     * Retorna la posicion actual.
     *
     * @return posicion.
     */
    public int getPosition()
    {
        return position;
    }

    /**
     * Cambia la posicion de la rueda.
     *
     * Se utiliza para las ruedas que copian otra rueda.
     *
     * @param newPosition nueva posicion.
     */
    protected void copyPosition(int newPosition)
    {
        if (symbols.size() == 0)
        {
            position = 0;
            return;
        }

        position = newPosition % symbols.size();

        if (position < 0)
        {
            position += symbols.size();
        }
    }

    /**
     * Indica si la rueda puede ser fijada.
     *
     * @return true si puede fijarse.
     */
    public boolean canFix()
    {
        return true;
    }

    /**
     * Indica si la rueda puede intercambiarse.
     *
     * @return true si puede intercambiarse.
     */
    public boolean canExchange()
    {
        return true;
    }

    /**
     * Indica si la rueda puede eliminarse.
     *
     * @return true si puede eliminarse.
     */
    public boolean canDelete()
    {
        return true;
    }

    /**
     * Retorna el tipo de rueda.
     *
     * @return tipo.
     */
    public String getType()
    {
        return "normal";
    }

    /**
     * Retorna el color de la ventana de la rueda.
     *
     * @return color.
     */
    public String getWindowColor()
    {
        return "white";
    }
    
    /**
     * Retorna el simbolo ubicado en una posicion.
     *
     * Este metodo permite consultar la rueda sin girarla.
     *
     * @param index posicion.
     * @return simbolo o null.
     */
    public Symbol getSymbolAt(int index)
    {
        if (index < 0 || index >= symbols.size())
        {
            return null;
        }
    
        return symbols.get(index);
    }
    
    /**
     * Dibuja los simbolos de la rueda.
     *
     * @param winX coordenada x.
     * @param winY coordenada y.
     * @param winW ancho.
     * @param winH alto.
     */
    public void drawInWindow(int winX, int winY, int winW, int winH)
    {
        for (Symbol s : symbols)
        {
            s.hideFigure();
        }

        int n = symbols.size();

        if (n == 0) return;

        Symbol current = getVisibleSymbol();

        if (n == 1)
        {
            current.moveTo(
                winX + (winW - current.getSize()) / 2,
                winY + (winH - current.getSize()) / 2
            );

            current.makeVisible();
            return;
        }

        Symbol prev = getPreviousSymbol();
        Symbol next = getNextSymbol();

        int paso = current.getSize() + 5;

        int centerX = winX + (winW - current.getSize()) / 2;
        int centerY = winY + (winH - current.getSize()) / 2;

        if (prev != null)
        {
            prev.moveTo(centerX, centerY - paso);
            prev.makeVisible();
        }

        if (current != null)
        {
            current.moveTo(centerX, centerY);
            current.makeVisible();
        }

        if (next != null)
        {
            next.moveTo(centerX, centerY + paso);
            next.makeVisible();
        }
    }
}