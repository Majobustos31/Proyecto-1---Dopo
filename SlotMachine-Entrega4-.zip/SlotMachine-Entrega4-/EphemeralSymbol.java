/**
 * Simbolo que disminuye de tamaño cada vez que la rueda gira.
 */
public class EphemeralSymbol extends Symbol
{
    private static final int DECREASE = 5;
    private static final int MIN_SIZE = 1;

    /**
     * Crea un simbolo ephemeral.
     *
     * @param name nombre.
     * @param color color.
     */
    public EphemeralSymbol(String name, String color)
    {
        super(name, color);
    }

    /**
     * Disminuye el tamaño cada vez que la rueda gira.
     */
    @Override
    public void onWheelSpin()
    {
        int newSize = getSize() - DECREASE;

        if (newSize < MIN_SIZE)
        {
            newSize = MIN_SIZE;
        }

        changeSize(newSize);
    }

    /**
     * Retorna el tipo del simbolo.
     *
     * @return tipo.
     */
    public String getType()
    {
        return "ephemeral";
    }
}