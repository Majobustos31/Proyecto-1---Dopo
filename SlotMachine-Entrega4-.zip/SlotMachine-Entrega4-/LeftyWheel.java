/**
 * Rueda que copia el estado de la rueda que tiene a su izquierda.
 */
public class LeftyWheel extends Wheel
{
    private Wheel leftWheel;

    /**
     * Crea una rueda Lefty.
     */
    public LeftyWheel()
    {
        super();
        leftWheel = null;
    }

    /**
     * Define la rueda de la izquierda.
     *
     * @param leftWheel rueda izquierda.
     */
    public void setLeftWheel(Wheel leftWheel)
    {
        this.leftWheel = leftWheel;
    }

    /**
     * Gira la rueda copiando el estado de la izquierda.
     *
     * @param steps numero de pasos.
     */
    @Override
    public void spin(int steps)
    {
        if (leftWheel == null)
        {
            super.spin(steps);
            return;
        }

        copyPosition(leftWheel.getPosition());

        Symbol selected = getVisibleSymbol();

        if (selected != null)
        {
            selected.onWheelSpin();
            selected.onSelected();
        }
    }

    /**
     * Retorna el tipo de rueda.
     *
     * @return lefty.
     */
    @Override
    public String getType()
    {
        return "lefty";
    }

    /**
     * Retorna el color visual.
     *
     * @return verde.
     */
    @Override
    public String getWindowColor()
    {
        return "green";
    }
}