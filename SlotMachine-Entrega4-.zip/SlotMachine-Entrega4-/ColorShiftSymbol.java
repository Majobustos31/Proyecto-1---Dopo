/**
 * Simbolo que cambia de color cada vez que es seleccionado.
 */
public class ColorShiftSymbol extends Symbol
{
    private String[] colors;
    private int colorPosition;

    /**
     * Crea un simbolo ColorShift.
     *
     * @param name nombre.
     * @param color color inicial.
     */
    public ColorShiftSymbol(String name, String color)
    {
        super(name, color);

        colors = new String[]
        {
            "red",
            "yellow",
            "green",
            "blue",
            "magenta"
        };

        colorPosition = findInitialColor(color);
    }

    /**
     * Busca la posicion del color inicial.
     *
     * @param color color inicial.
     * @return posicion del color.
     */
    private int findInitialColor(String color)
    {
        for (int i = 0; i < colors.length; i++)
        {
            if (colors[i].equals(color))
            {
                return i;
            }
        }

        return 0;
    }

    /**
     * Cambia al siguiente color.
     */
    @Override
    public void onSelected()
    {
        colorPosition = (colorPosition + 1) % colors.length;
        changeSymbolColor(colors[colorPosition]);
    }

    /**
     * Retorna el tipo del simbolo.
     *
     * @return tipo.
     */
    public String getType()
    {
        return "colorShift";
    }
}