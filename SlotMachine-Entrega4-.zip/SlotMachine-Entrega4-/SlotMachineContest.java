/**
 * Permite resolver una configuracion de la maquina tragamonedas.
 *
 * La clase trabaja sobre una representacion de la maquina
 * independiente de SlotMachine.
 */
public class SlotMachineContest
{
    /**
     * Resuelve la configuracion de la maquina.
     *
     * Cada fila representa una rueda.
     * Cada posicion de la fila representa el simbolo
     * que aparece en esa posicion de la rueda.
     *
     * La posicion 0 representa el simbolo actualmente visible.
     *
     * El metodo retorna cuantos pasos debe girar cada rueda
     * para que todas terminen mostrando el mismo simbolo.
     *
     * @param machine configuracion de las ruedas.
     * @return pasos que debe girar cada rueda.
     */
    public static int[] solve(String[][] machine)
    {
        int n = machine.length;
        int[] solution = new int[n];

        if (n == 0)
        {
            return solution;
        }

        if (machine[0] == null || machine[0].length == 0)
        {
            return solution;
        }

        String target = machine[0][0];

        for (int i = 0; i < n; i++)
        {
            solution[i] = findSymbol(machine[i], target);
        }

        return solution;
    }

    /**
     * Busca la posicion de un simbolo dentro de una rueda.
     *
     * @param wheel rueda que se consulta.
     * @param target simbolo que se busca.
     * @return posicion del simbolo o -1 si no existe.
     */
    private static int findSymbol(String[] wheel, String target)
    {
        if (wheel == null)
        {
            return -1;
        }

        for (int i = 0; i < wheel.length; i++)
        {
            if (target.equals(wheel[i]))
            {
                return i;
            }
        }

        return -1;
    }

    /**
     * Simula la solucion sobre una maquina.
     *
     * @param machine configuracion inicial.
     * @param solution pasos que debe girar cada rueda.
     * @return true si todas las ruedas terminan mostrando
     *         el mismo simbolo.
     */
    public static boolean simulate(String[][] machine, int[] solution)
    {
        if (machine == null || solution == null)
        {
            return false;
        }

        int n = machine.length;

        if (n == 0 || solution.length != n)
        {
            return false;
        }

        int symbolsPerWheel = machine[0].length;

        if (symbolsPerWheel == 0)
        {
            return false;
        }

        for (int i = 0; i < n; i++)
        {
            if (machine[i] == null ||
                machine[i].length != symbolsPerWheel)
            {
                return false;
            }
        }

        String finalSymbol = null;

        for (int i = 0; i < n; i++)
        {
            int position =
                solution[i] % symbolsPerWheel;

            if (position < 0)
            {
                position += symbolsPerWheel;
            }

            String symbol = machine[i][position];

            if (i == 0)
            {
                finalSymbol = symbol;
            }
            else if (!finalSymbol.equals(symbol))
            {
                return false;
            }
        }

        return true;
    }
}