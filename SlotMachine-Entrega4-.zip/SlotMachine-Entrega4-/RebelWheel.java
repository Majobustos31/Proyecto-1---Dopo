/**
 * Rueda rebelde.
 *
 * No puede ser fijada, intercambiada ni eliminada.
 */
public class RebelWheel extends Wheel
{
    /**
     * Crea una rueda rebel.
     */
    public RebelWheel()
    {
        super();
    }

    /**
     * Una rebel no puede fijarse.
     *
     * @return false.
     */
    @Override
    public boolean canFix()
    {
        return false;
    }

    /**
     * Una rebel no puede intercambiarse.
     *
     * @return false.
     */
    @Override
    public boolean canExchange()
    {
        return false;
    }

    /**
     * Una rebel no puede eliminarse.
     *
     * @return false.
     */
    @Override
    public boolean canDelete()
    {
        return false;
    }

    /**
     * Retorna el tipo.
     *
     * @return rebel.
     */
    @Override
    public String getType()
    {
        return "rebel";
    }

    /**
     * Color visual de la rebel.
     *
     * @return amarillo.
     */
    @Override
    public String getWindowColor()
    {
        return "yellow";
    }
}